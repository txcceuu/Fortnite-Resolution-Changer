#include <windows.h>
#include <string>
#include <fstream>
#include <sstream>
#include <regex>

#define IDC_WIDTH_INPUT 101
#define IDC_HEIGHT_INPUT 102
#define IDC_APPLY_BUTTON 103

std::wstring findFortniteConfigPath() {
    wchar_t* appdata_local_env = nullptr;
    size_t required_size;

    if (_wdupenv_s(&appdata_local_env, &required_size, L"LOCALAPPDATA") != 0 || appdata_local_env == nullptr) {
        MessageBoxW(NULL, L"Error: LOCALAPPDATA environment variable not found.", L"Error", MB_ICONERROR);
        return L"";
    }

    std::wstring config_path = appdata_local_env;
    free(appdata_local_env);

    config_path += L"\\FortniteGame\\Saved\\Config\\WindowsClient\\GameUserSettings.ini";
    return config_path;
}

void changeFortniteResolution(int width, int height) {
    std::wstring config_file_path = findFortniteConfigPath();

    if (config_file_path.empty()) {
        MessageBoxW(NULL, L"Could not determine Fortnite config file path.", L"Error", MB_ICONERROR);
        return;
    }

    std::wifstream infile(config_file_path);
    if (!infile.good()) {
        MessageBoxW(NULL, L"GameUserSettings.ini not found. Please run Fortnite once.", L"Error", MB_ICONERROR);
        return;
    }

    std::wstringstream buffer;
    buffer << infile.rdbuf();
    std::wstring content = buffer.str();
    infile.close();

    try {
        content = std::regex_replace(content, std::wregex(L"ResolutionSizeX=\\d+"), L"ResolutionSizeX=" + std::to_wstring(width));
        content = std::regex_replace(content, std::wregex(L"ResolutionSizeY=\\d+"), L"ResolutionSizeY=" + std::to_wstring(height));

        content = std::regex_replace(content, std::wregex(L"LastUserConfirmedResolutionSizeX=\\d+"), L"LastUserConfirmedResolutionSizeX=" + std::to_wstring(width));
        content = std::regex_replace(content, std::wregex(L"LastUserConfirmedResolutionSizeY=\\d+"), L"LastUserConfirmedResolutionSizeY=" + std::to_wstring(height));

        content = std::regex_replace(content, std::wregex(L"DesiredScreenWidth=\\d+"), L"DesiredScreenWidth=" + std::to_wstring(width));
        content = std::regex_replace(content, std::wregex(L"DesiredScreenHeight=\\d+"), L"DesiredScreenHeight=" + std::to_wstring(height));

        content = std::regex_replace(content, std::wregex(L"LastUserConfirmedDesiredScreenWidth=\\d+"), L"LastUserConfirmedDesiredScreenWidth=" + std::to_wstring(width));
        content = std::regex_replace(content, std::wregex(L"LastUserConfirmedDesiredScreenHeight=\\d+"), L"LastUserConfirmedDesiredScreenHeight=" + std::to_wstring(height));

        content = std::regex_replace(content, std::wregex(L"FullscreenMode=\\d+"), L"FullscreenMode=1");
        content = std::regex_replace(content, std::wregex(L"LastConfirmedFullscreenMode=\\d+"), L"LastConfirmedFullscreenMode=1");

        std::wofstream outfile(config_file_path, std::ios::trunc);
        if (!outfile.is_open()) {
            MessageBoxW(NULL, L"Could not write to GameUserSettings.ini.", L"Error", MB_ICONERROR);
            return;
        }
        outfile << content;
        outfile.close();

        MessageBoxW(NULL, L"Successfully updated Fortnite resolution.", L"Success", MB_OK);
    }
    catch (const std::exception& e) {
        MessageBoxW(NULL, L"An error occurred while updating the file.", L"Error", MB_ICONERROR);
    }
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    case WM_CREATE: {
        CreateWindowW(L"STATIC", L"Width:", WS_VISIBLE | WS_CHILD, 20, 20, 50, 20, hwnd, NULL, NULL, NULL);
        CreateWindowW(L"EDIT", NULL, WS_VISIBLE | WS_CHILD | WS_BORDER | ES_NUMBER, 80, 20, 100, 20, hwnd, (HMENU)IDC_WIDTH_INPUT, NULL, NULL);

        CreateWindowW(L"STATIC", L"Height:", WS_VISIBLE | WS_CHILD, 20, 60, 50, 20, hwnd, NULL, NULL, NULL);
        CreateWindowW(L"EDIT", NULL, WS_VISIBLE | WS_CHILD | WS_BORDER | ES_NUMBER, 80, 60, 100, 20, hwnd, (HMENU)IDC_HEIGHT_INPUT, NULL, NULL);

        CreateWindowW(L"BUTTON", L"Apply", WS_VISIBLE | WS_CHILD, 80, 100, 100, 30, hwnd, (HMENU)IDC_APPLY_BUTTON, NULL, NULL);
        break;
    }
    case WM_COMMAND: {
        if (LOWORD(wParam) == IDC_APPLY_BUTTON) {
            wchar_t widthStr[10], heightStr[10];
            GetWindowTextW(GetDlgItem(hwnd, IDC_WIDTH_INPUT), widthStr, 10);
            GetWindowTextW(GetDlgItem(hwnd, IDC_HEIGHT_INPUT), heightStr, 10);

            int width = _wtoi(widthStr);
            int height = _wtoi(heightStr);

            if (width > 0 && height > 0)
                changeFortniteResolution(width, height);
            else
                MessageBoxW(hwnd, L"Invalid resolution.", L"Input Error", MB_ICONERROR);
        }
        break;
    }
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, PWSTR, int nCmdShow) {
    const wchar_t CLASS_NAME[] = L"FortniteResChanger";

    WNDCLASS wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;

    RegisterClass(&wc);

    HWND hwnd = CreateWindowExW(
        0, CLASS_NAME, L"Fortnite Resolution Changer",
        WS_OVERLAPPEDWINDOW ^ WS_THICKFRAME ^ WS_MAXIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, 300, 200,
        NULL, NULL, hInstance, NULL);

    if (!hwnd) return 0;

    ShowWindow(hwnd, nCmdShow);

    MSG msg = {};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return 0;
}